import 'package:coolapp/cart.dart';
import 'package:flutter/material.dart';

import 'cart_inherited.dart';
import 'photo_detail.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return CartInheritedWidget(
        cart: CartModel(<int>[1, 2, 3]),
        child: MaterialApp(
          title: 'Flutter Demo',
          theme: ThemeData.dark(),
          home: MyHomePage(title: 'Flutter Demo Home Page'),
        ));
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);
  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(child: itemsGrid(context)),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            CartInheritedWidget.of(context).smartphonesIds.add(2);
          });
        },
        tooltip: 'Increment',
        child: Icon(Icons.add),
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  itemsGrid(BuildContext context) {
    List ids = CartInheritedWidget.of(context)
        .smartphonesIds;

    List widget = ids.map((it) => itemGrid(it))
        .toList();

    return GridView.count(
        crossAxisCount: 3,
        children: widget
    );
  }

  Widget itemGrid(int id) {
    return GestureDetector(
        onTap: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => PhotoDetail()));
        },
        child: Image(
          image: AssetImage('images/$id.jpg'),
        ));
  }
}
