class CartModel{
  final List<int> smartphonesIds;

  CartModel(this.smartphonesIds);
}