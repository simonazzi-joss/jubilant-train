import 'package:coolapp/cart.dart';
import 'package:flutter/cupertino.dart';

class CartInheritedWidget extends InheritedWidget{

  final CartModel cart;

  const CartInheritedWidget({Key key, @required this.cart, @required Widget child})
  :super(key:key, child: child);

  static CartModel of(BuildContext context){
    final widget = context.dependOnInheritedWidgetOfExactType<CartInheritedWidget>();
    return widget.cart;
  }

  @override
  bool updateShouldNotify(InheritedWidget oldWidget) {
     return true;
  }

}